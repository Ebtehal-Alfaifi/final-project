package com.example.dealify.InDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BlackListInDTO {//Waleed
    private String reason;
}
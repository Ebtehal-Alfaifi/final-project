package com.example.dealify.Api;

public class ApiException extends RuntimeException{
    public ApiException(String message){
        super(message);
    }
}